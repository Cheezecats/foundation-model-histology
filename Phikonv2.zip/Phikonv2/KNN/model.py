from sklearn.neighbors import KNeighborsClassifier
from sklearn.decomposition import IncrementalPCA
import numpy as np
import torch

class KNNModel:
    def __init__(self, n_neighbors=5, weights='distance', n_components=100, batch_size=5000):
        self.n_neighbors = n_neighbors
        self.weights = weights
        self.batch_size = batch_size
        self.pca = IncrementalPCA(n_components=n_components, whiten=True) if n_components else None  # Added whiten
        self.model = KNeighborsClassifier(
            n_neighbors=n_neighbors, 
            weights=weights, 
            algorithm='auto',  # Let it choose best algorithm
            metric='cosine'  # Often better for embeddings
        )
        self.feature_mean = None
        self.feature_std = None

    def _convert_to_numpy(self, data):
        """Convert input to numpy array efficiently"""
        if isinstance(data, torch.Tensor):
            return data.numpy()
        elif isinstance(data, np.ndarray):
            return data
        else:
            return np.array(data)
        
    def _normalize_features(self, X):
        """Normalize features to zero mean and unit variance"""
        if self.feature_mean is None:
            self.feature_mean = X.mean(axis=0)
            self.feature_std = X.std(axis=0) + 1e-8  # Avoid division by zero
            
        return (X - self.feature_mean) / self.feature_std
        
    def fit(self, X, y):
        X = self._convert_to_numpy(X)
        y = y.numpy() if isinstance(y, torch.Tensor) else y
        
        if X.ndim > 2:
            X = X.reshape(X.shape[0], -1)
            
        # Normalize features first
        X = self._normalize_features(X)
            
        if self.pca:
            print(f"Original shape: {X.shape}")
            for i in range(0, len(X), self.batch_size):
                batch = X[i:i+self.batch_size]
                self.pca.partial_fit(batch)
            X = self.pca.transform(X)
            print(f"After PCA shape: {X.shape}")
            explained_variance = self.pca.explained_variance_ratio_.sum()
            print(f"Explained variance: {explained_variance:.2f}")
            
        self.model.fit(X, y)
        
    def predict_proba(self, X):
        X = self._convert_to_numpy(X)
        if X.ndim > 2:
            X = X.reshape(X.shape[0], -1)
        if self.pca:
            X = self.pca.transform(X)
        return self.model.predict_proba(X)
        
    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)