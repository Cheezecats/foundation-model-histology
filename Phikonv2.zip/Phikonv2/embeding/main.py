import torch
from torch.utils.data import DataLoader
import h5py
import numpy as np
from tqdm import tqdm
from dataloader import CRCDataset, create_phikon_model
from torchvision import transforms


def calculate_required_space(num_images):
    """Calculate approximate disk space needed in bytes"""
    feature_dim = 768  # phikon output dimension
    return num_images * (feature_dim + 196 * feature_dim) * 2  # float16 = 2 bytes


def extract_features(model, processor, dataloader, output_path):
    device = next(model.parameters()).device
    num_samples = len(dataloader.dataset)
    feature_dim = 768  # phikon output dimension
    
    with h5py.File(output_path, 'w') as f:
        cls_dset = f.create_dataset(
            'cls_token', (num_samples, feature_dim),
            dtype='float16', chunks=(1024, feature_dim)
        )
        patches_dset = f.create_dataset(
            'patch_tokens', (num_samples, 196, feature_dim),
            dtype='float16', chunks=(128, 196, feature_dim)
        )
        labels_dset = f.create_dataset(
            'labels', (num_samples,),
            dtype='int64', chunks=True
        )
        
        start_idx = 0
        with torch.inference_mode():
            for images, labels in tqdm(dataloader, desc="Extracting features"):
                pil_images = [transforms.ToPILImage()(img) for img in images]
                inputs = processor(images=pil_images, return_tensors="pt")
                inputs = {k: v.to(device) for k, v in inputs.items()}
                
                outputs = model(**inputs, output_hidden_states=True)
                cls_token = outputs.last_hidden_state[:, 0, :]    # [B, 768]
                patch_tokens = outputs.last_hidden_state[:, 1:, :] # [B, 196, 768]

                # Safety checks
                assert cls_token.shape[-1] == feature_dim, f"Expected {feature_dim}-D, got {cls_token.shape[-1]}"
                assert patch_tokens.shape[1] == 196, f"Expected 196 patch tokens, got {patch_tokens.shape[1]}"

                batch_size = images.shape[0]
                end_idx = start_idx + batch_size
                cls_dset[start_idx:end_idx] = cls_token.float().cpu().numpy()
                patches_dset[start_idx:end_idx] = patch_tokens.float().cpu().numpy()
                labels_dset[start_idx:end_idx] = np.asarray(labels, dtype=np.int64)
                start_idx = end_idx


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")
    
    model, processor = create_phikon_model()  # owkin/phikon => 768-D
    model = model.to(device)
    
    data_path = "NCT-CRC-HE-100K-png"
    print(f"Loading dataset from: {data_path}")
    dataset = CRCDataset(data_path)
    loader = DataLoader(
        dataset,
        batch_size=32,
        shuffle=False,
        num_workers=8,
        prefetch_factor=2,
        pin_memory=True
    )
    
    print(f"Found {len(dataset)} images")
    
    output_path = "E:/crc_phikon_features.h5"
    print(f"\nStarting feature extraction to {output_path}...")
    print(f"Estimated required space: {calculate_required_space(len(dataset))/1e9:.2f}GB")
    
    extract_features(model, processor, loader, output_path)
    print("\nFeature extraction completed successfully!")