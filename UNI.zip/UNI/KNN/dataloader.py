# dataloader.py
import torch
from torch.utils.data import Dataset, DataLoader
import h5py
import numpy as np

class CRCDataset(Dataset):
    def __init__(self, hdf5_path, transform=None, max_ram_batch=10000):
        self.file_path = hdf5_path
        self.transform = transform
        self.max_ram_batch = max_ram_batch
        self.current_batch = None
        self.batch_start_idx = 0
        
        with h5py.File(hdf5_path, 'r') as f:
            self.total_samples = len(f['labels'])

    def __len__(self):
        return self.total_samples

    def _load_batch(self, idx):
        """Load a chunk of data surrounding the requested index"""
        batch_start = max(0, idx - (self.max_ram_batch // 2))
        batch_end = min(self.total_samples, batch_start + self.max_ram_batch)
        
        with h5py.File(self.file_path, 'r') as f:
            self.current_batch = {
                'cls_token': f['cls_token'][batch_start:batch_end],
                'labels': f['labels'][batch_start:batch_end]
            }
        self.batch_start_idx = batch_start

    def __getitem__(self, idx):
        if (self.current_batch is None or 
            idx < self.batch_start_idx or 
            idx >= self.batch_start_idx + self.max_ram_batch):
            self._load_batch(idx)
            
        local_idx = idx - self.batch_start_idx
        embedding = self.current_batch['cls_token'][local_idx]
        label = int(self.current_batch['labels'][local_idx])
        
        if self.transform:
            embedding = self.transform(embedding)
            
        return embedding, label
    
def get_data_loaders(train_hdf5_path, val_hdf5_path, batch_size=32, num_workers=0):
    # Create separate datasets for train and validation
    train_dataset = CRCDataset(train_hdf5_path, max_ram_batch=1024)
    val_dataset = CRCDataset(val_hdf5_path, max_ram_batch=1024)
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        persistent_workers=False
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        persistent_workers=False
    )
    
    return train_loader, val_loader