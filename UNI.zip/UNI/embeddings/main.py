import torch
from torch.utils.data import DataLoader
import h5py
import numpy as np
from tqdm import tqdm
from dataloader import CRCDataset, create_UNI_model
import os
import math
import shutil


def calculate_required_space(num_images):
    """Calculate approximate disk space needed in bytes"""
    # cls_token: 100000 × 1280 × 2 bytes (float32) = ~244MB
    # patch_tokens: 100000 × 256 × 1280 × 2 bytes = ~61GB
    return (num_images * (1280*2 + 256*1280*2))

def extract_features(model, dataloader, output_path):
    device = next(model.parameters()).device
    num_samples = len(dataloader.dataset)
    
    # First pass to determine feature dimensions
    with torch.no_grad():
        sample_output = model.forward_features(torch.randn(1, 3, 224, 224).to(device))
        feature_dim = sample_output.shape[-1]
        num_patches = sample_output.shape[1] - 1  # minus cls token
    
    print(f"Detected feature dimensions: {feature_dim} (expected 1280)")
    print(f"Detected number of patches: {num_patches} (expected 256)")
    
    # Check disk space with actual dimensions
    required_space = num_samples * (feature_dim*2 + num_patches*feature_dim*2)
    total, used, free = shutil.disk_usage(os.path.dirname(output_path))
    if free < required_space * 1.2:
        raise ValueError(f"Insufficient disk space. Need {required_space/1e9:.2f}GB, only {free/1e9:.2f}GB available")
    
    with h5py.File(output_path, 'w') as f:
        # Create datasets with detected dimensions
        cls_dset = f.create_dataset('cls_token', (num_samples, feature_dim), 
                                  dtype='float16', chunks=(1024, feature_dim))
        patches_dset = f.create_dataset('patch_tokens', (num_samples, num_patches, feature_dim), 
                                      dtype='float16', chunks=(128, num_patches, feature_dim))
        labels_dset = f.create_dataset('labels', data=np.array(dataloader.dataset.labels))
        
        start_idx = 0
        with torch.inference_mode(), torch.autocast(device_type="cuda", dtype=torch.float16):
            for images, _ in tqdm(dataloader, desc="Extracting features"):
                images = images.to(device, non_blocking=True)
                output = model.forward_features(images)
                
                batch_size = images.shape[0]
                class_token = output[:, 0]  # [B, feature_dim]
                patch_tokens = output[:, 1:1+num_patches]  # [B, num_patches, feature_dim]

                # Store results
                end_idx = start_idx + batch_size
                cls_dset[start_idx:end_idx] = class_token.float().cpu().numpy().astype('float16')
                patches_dset[start_idx:end_idx] = patch_tokens.float().cpu().numpy().astype('float16')
                start_idx = end_idx
                
                if start_idx % 50000 == 0:
                    f.flush()
                    print(f"Checkpoint: Processed {start_idx}/{num_samples} images")

if __name__ == "__main__":
    # Initialize
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")
    
    # Create model
    model, _ = create_UNI_model()
    model = model.to(device)
    
    # Create dataset and loader
    data_path = "NCT-CRC-HE-100K-png"  # Update with your correct path
    # data_path = "CRC-VAL-HE-7K-png"
    print(f"Loading dataset from: {data_path}")
    dataset = CRCDataset(data_path)
    loader = DataLoader(
        dataset,
        batch_size=128,  # Increased batch size for efficiency
        shuffle=False,
        num_workers=16,
        prefetch_factor=4,
        pin_memory=True
    )
    
    print(f"Found {len(dataset)} images")
    if len(dataset) != 100000:
        print(f"Warning: Expected 100,000 images, found {len(dataset)}")
    
    # Set output path on E: drive
    output_path = "E:/crc_UNI_features.h5"
    print(f"\nStarting feature extraction to {output_path}...")
    print(f"Estimated required space: {calculate_required_space(len(dataset))/1e9:.2f}GB")
    
    # Run extraction
    extract_features(model, loader, output_path)
    print("\nFeature extraction completed successfully!")