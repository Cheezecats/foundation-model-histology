# main.py
import torch
import torch.nn as nn
import torch.optim as optim
import os

from model import AttentionModel
from dataloader import get_data_loaders
from training_manager import TrainingManager, EarlyStopping
from vis_utils import visualize_model_performance

device = "cuda" if torch.cuda.is_available() else "cpu"

def main():
    # Hyperparameters
    learning_rate = 0.0001
    num_epochs = 50
    batch_size = 32
    
    # Paths to your separate train and validation HDF5 files
    train_hdf5_path = "E:/crc_virchow2_features.h5"
    val_hdf5_path = "E:/crc_val_virchow2_features.h5"

    # Initialize model
    model = AttentionModel(input_dim=1280, num_classes=9).to(device)
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
    early_stopping = EarlyStopping(patience=5, min_delta=0.01)

    # Get data loaders
    train_loader, val_loader = get_data_loaders(
        train_hdf5_path=train_hdf5_path,
        val_hdf5_path=val_hdf5_path,
        batch_size=batch_size
    )

    # Verify data shapes
    sample_batch = next(iter(train_loader))
    print(f"Train batch - data shape: {sample_batch[0].shape}, targets shape: {sample_batch[1].shape}")


    trainer = TrainingManager(
        model,
        optimizer,
        criterion,
        early_stopping,
        logdir="runs/virchow2_attention_pooling",
        monitor="val_loss",
        device=device,
        batch_log_interval=10,  # Log every 10 batches
    )
    
    trainer.num_epochs = num_epochs
    trainer.train(num_epochs, train_loader, val_loader)
    
    best_model_path = 'best_crc_attention_model.pth'
    torch.save(trainer.get_best_model(), best_model_path)
    print(f"\nBest model saved to {best_model_path}")

    # Load the best model for visualization
    print("\nLoading best model for final evaluation and visualization...")
    best_model_state = trainer.get_best_model()
    model.load_state_dict(best_model_state)

    cm_fig, roc_fig = visualize_model_performance(
        model, 
        val_loader, 
        device,
        class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
    )
    
    from pathlib import Path
    fig_dir = Path(__file__).parent / "figs_attention"
    os.makedirs(fig_dir, exist_ok=True)
    cm_fig.savefig(os.path.join(fig_dir, "confusion_matrix.png"), bbox_inches='tight')
    roc_fig.savefig(os.path.join(fig_dir, "roc_curve.png"), bbox_inches='tight')
    print(f"Visualization figures saved in '{fig_dir}' directory.")

if __name__ == "__main__":
    main()