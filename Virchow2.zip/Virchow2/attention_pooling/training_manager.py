import torch
import torch.nn as nn
from torch.optim import Optimizer
from torch.utils.tensorboard.writer import SummaryWriter
from torch.utils.data.dataloader import DataLoader
from typing import Literal

class EarlyStopping:
    """Early stopping to prevent overfitting. This class is correct."""
    def __init__(self, patience: int, min_delta: float):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.best_model = None

    def __call__(self, current_value: float, model: nn.Module):
        if self.best_loss is None:
            self.best_loss = current_value
            self.best_model = self._get_model_copy(model)
            return False

        if current_value < self.best_loss - self.min_delta:
            self.best_loss = current_value
            self.counter = 0
            self.best_model = self._get_model_copy(model)
        else:
            self.counter += 1

        if self.counter >= self.patience:
            return True
        return False

    def _get_model_copy(self, model: nn.Module) -> dict:
        return {
            key: val.cpu().clone().detach()
            for key, val in model.state_dict().items()
        }

class TrainingManager:
    def __init__(
        self,
        model: nn.Module,
        optimizer: Optimizer,
        criterion: nn.Module,
        early_stopping: EarlyStopping,
        logdir: str,
        monitor: Literal["val_loss"] | Literal["val_acc"],
        device: str,
        batch_log_interval: int = 10,  # consistent batch logging interval
    ):
        self.model = model
        self.optimizer = optimizer
        self.criterion = criterion
        self.device = device
        self.writer = SummaryWriter(logdir)
        self.model.to(device)
        self.monitor = monitor
        self.early_stopping = early_stopping
        self.batch_log_interval = batch_log_interval
        self.num_epochs = 0  # will be set in train()

    def train(self, num_epochs: int, train_loader: DataLoader, val_loader: DataLoader):
        self.num_epochs = num_epochs
        for epoch in range(num_epochs):
            self.train_epoch(train_loader, epoch)
            val_loss, val_acc = self.validate(val_loader, epoch, train_loader)

            monitor_value = val_loss if self.monitor == "val_loss" else val_acc
            if self.early_stopping(monitor_value, self.model):
                print(f"\nEarly stopping triggered after epoch {epoch + 1}")
                break

    def train_epoch(self, train_loader: DataLoader, epoch: int):
        self.model.train()
        running_loss, correct, total = 0.0, 0, 0

        for batch_idx, (data, targets) in enumerate(train_loader):
            data, targets = data.to(self.device), targets.to(self.device)

            self.optimizer.zero_grad()
            outputs = self.model(data)
            loss = self.criterion(outputs, targets)

            loss.backward()
            self.optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += targets.size(0)
            correct += (predicted == targets).sum().item()

            # Log every N batches consistently
            if (batch_idx + 1) % self.batch_log_interval == 0:
                avg_loss = running_loss / (batch_idx + 1)
                avg_acc = 100.0 * correct / total
                print(f"Epoch [{epoch+1}/{self.num_epochs}], Batch [{batch_idx+1}/{len(train_loader)}], Loss: {avg_loss:.4f}, Acc: {avg_acc:.2f}%")
                global_step = epoch * len(train_loader) + batch_idx
                self.writer.add_scalar("Loss/train_batch", avg_loss, global_step)
                self.writer.add_scalar("Accuracy/train_batch", avg_acc, global_step)


    def validate(self, val_loader: DataLoader, epoch: int, train_loader=None):
        self.model.eval()
        val_loss, correct, total = 0, 0, 0
        with torch.no_grad():
            for data, targets in val_loader:
                data, targets = data.to(self.device), targets.to(self.device)
                outputs = self.model(data)
                loss = self.criterion(outputs, targets)
                val_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                total += targets.size(0)
                correct += (predicted == targets).sum().item()
        val_loss /= len(val_loader)
        val_acc = 100.0 * correct / total
        # Use global step for validation
        if train_loader is not None:
            global_step = (epoch + 1) * len(train_loader) - 1
        else:
            global_step = epoch
        self.writer.add_scalar("Val/Loss", val_loss, global_step)
        self.writer.add_scalar("Val/Accuracy", val_acc, global_step)
        print(f"Validation - Loss: {val_loss:.4f}, Accuracy: {val_acc:.2f}%")
        return val_loss, val_acc

    def get_best_model(self) -> dict:
        if self.early_stopping.best_model is None:
            raise Exception("Training not started or no best model saved.")
        return self.early_stopping.best_model