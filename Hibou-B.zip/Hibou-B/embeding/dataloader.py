from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset
from transformers import AutoImageProcessor, AutoModel
from torchvision import transforms


def create_phikon_model():
    """Initialize phikon model with processor"""
    processor = AutoImageProcessor.from_pretrained("histai/hibou-b", trust_remote_code=True)
    model = AutoModel.from_pretrained("histai/hibou-b", trust_remote_code=True)
    model = model.eval()
    return model, processor


class CRCDataset(Dataset):
    def __init__(self, root_dir):
        self.root_dir = Path(root_dir).absolute()
        # Class names exactly as label indices 0..8
        self.classes = ['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
        self.class_to_idx = {cls: i for i, cls in enumerate(self.classes)}
        
        # Basic transform to convert PIL to tensor
        self.to_tensor = transforms.ToTensor()
        
        # Collect all image paths and labels
        self.image_paths = []
        self.labels = []
        
        # If your images may be in subfolders, change to rglob("*.png")
        for img_path in self.root_dir.glob("*.png"):
            filename = img_path.stem.upper()

            # Match any class name that is a prefix of the filename
            matched_class = next((cls for cls in self.classes if filename.startswith(cls)), None)
            if matched_class is not None:
                self.image_paths.append(img_path)
                self.labels.append(self.class_to_idx[matched_class])

    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        img = Image.open(self.image_paths[idx])
        if img.mode != 'RGB':
            img = img.convert('RGB')
        return self.to_tensor(img), self.labels[idx]