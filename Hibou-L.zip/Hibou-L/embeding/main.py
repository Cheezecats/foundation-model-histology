import torch
from torch.utils.data import DataLoader
import h5py
import numpy as np
from tqdm import tqdm
from dataloader import CRCDataset, create_phikon_model
from torchvision import transforms


def calculate_required_space(num_images, feature_dim, patch_count):
    """Calculate approximate disk space needed in bytes"""
    return num_images * (feature_dim + patch_count * feature_dim) * 2  # float16 = 2 bytes


def extract_features(model, processor, dataloader, output_path):
    device = next(model.parameters()).device
    num_samples = len(dataloader.dataset)

    # ---- Detect feature_dim & patch_count dynamically from first batch ----
    first_images, _ = next(iter(dataloader))
    pil_images = [transforms.ToPILImage()(img) for img in first_images]
    inputs = processor(images=pil_images, return_tensors="pt").to(device)
    with torch.inference_mode():
        outputs = model(**inputs, output_hidden_states=True)
    feature_dim = outputs.last_hidden_state.shape[-1]
    patch_count = outputs.last_hidden_state.shape[1] - 1
    print(f"Detected feature_dim={feature_dim}, patch_count={patch_count}")

    # ---- Create datasets ----
    with h5py.File(output_path, 'w') as f:
        cls_dset = f.create_dataset(
            'cls_token', (num_samples, feature_dim),
            dtype='float16', chunks=(1024, feature_dim)
        )
        patches_dset = f.create_dataset(
            'patch_tokens', (num_samples, patch_count, feature_dim),
            dtype='float16', chunks=(128, patch_count, feature_dim)
        )
        labels_dset = f.create_dataset(
            'labels', (num_samples,),
            dtype='int64', chunks=True
        )

        # ---- Feature extraction loop ----
        start_idx = 0
        with torch.inference_mode():
            for images, labels in tqdm(dataloader, desc="Extracting features"):
                pil_images = [transforms.ToPILImage()(img) for img in images]
                inputs = processor(images=pil_images, return_tensors="pt")
                inputs = {k: v.to(device) for k, v in inputs.items()}

                outputs = model(**inputs, output_hidden_states=True)
                cls_token = outputs.last_hidden_state[:, 0, :]     # [B, feature_dim]
                patch_tokens = outputs.last_hidden_state[:, 1:, :] # [B, patch_count, feature_dim]

                batch_size = images.shape[0]
                end_idx = start_idx + batch_size
                cls_dset[start_idx:end_idx] = cls_token.float().cpu().numpy()
                patches_dset[start_idx:end_idx] = patch_tokens.float().cpu().numpy()
                labels_dset[start_idx:end_idx] = np.asarray(labels, dtype=np.int64)
                start_idx = end_idx

    return feature_dim, patch_count


if __name__ == "__main__":
    # Initialize
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    # Create model and processor
    model, processor = create_phikon_model()
    model = model.to(device)

    # Create dataset and loader
    data_path = "CRC-VAL-HE-7K-png"
    print(f"Loading dataset from: {data_path}")
    dataset = CRCDataset(data_path)
    loader = DataLoader(
        dataset,
        batch_size=32,
        shuffle=False,       # keep order aligned with on-disk writing
        num_workers=8,
        prefetch_factor=2,
        pin_memory=True
    )

    print(f"Found {len(dataset)} images")

    # Output path
    output_path = "E:/crc_val_Hibou_L_features.h5"
    print(f"\nStarting feature extraction to {output_path}...")

    # Run extraction
    feature_dim, patch_count = extract_features(model, processor, loader, output_path)
    print(f"Estimated required space: {calculate_required_space(len(dataset), feature_dim, patch_count)/1e9:.2f}GB")

    print("\nFeature extraction completed successfully!")
