import matplotlib.figure
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
from sklearn.metrics import (
    confusion_matrix,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_curve,
    roc_auc_score,
)
import torch
from torch.utils.data.dataloader import DataLoader
import numpy as np

# --- FIX: Robust evaluation function for models like KNN ---
def evaluate_model(
    model, val_loader: DataLoader, device: str, num_total_classes: int
) -> tuple[list[float], list[float], list[float]]:
    """
    Evaluate the model, handling cases where the model was trained on fewer classes
    than are possible. Returns true labels, full probability matrix, and predicted labels.
    """
    true_labels = []
    all_pred_probs = []
    all_pred_labels = []

    # Get the actual class labels the sklearn model was trained on.
    model_known_classes = model.model.classes_

    for data, targets in val_loader:
        # Get probabilities only for the classes the model knows.
        pred_prob_known_classes = model.predict_proba(data)
        predicted_labels = model.predict(data)

        # Create a full probability matrix initialized with zeros.
        full_pred_probs = np.zeros((data.shape[0], num_total_classes))

        # Place the predicted probabilities into the correct columns.
        for i, class_idx in enumerate(model_known_classes):
            full_pred_probs[:, class_idx] = pred_prob_known_classes[:, i]

        all_pred_probs.extend(full_pred_probs)
        all_pred_labels.extend(predicted_labels)
        true_labels.extend(targets.numpy())

    return true_labels, all_pred_probs, all_pred_labels
# --- END FIX ---

def plot_confusion_matrix(
    true_labels,
    pred_labels,
    class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
) -> matplotlib.figure.Figure:
    """
    Plot confusion matrix with metrics.
    """
    accuracy = accuracy_score(true_labels, pred_labels)
    precision = precision_score(true_labels, pred_labels, average='macro', zero_division=0)
    recall = recall_score(true_labels, pred_labels, average='macro', zero_division=0)
    f1 = f1_score(true_labels, pred_labels, average='macro', zero_division=0)

    cm = confusion_matrix(true_labels, pred_labels, labels=range(len(class_names)))
    fig, ax = plt.subplots(figsize=(14, 12))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, xticklabels=class_names, yticklabels=class_names, annot_kws={"size": 10}, ax=ax)
    ax.set_xticklabels(class_names, rotation=45, ha='right', rotation_mode='anchor', fontsize=10)
    ax.set_yticklabels(class_names, rotation=0, fontsize=10, va='center')
    plt.title("Confusion Matrix", pad=25, fontsize=14, weight='bold')
    plt.xlabel("Predicted Label", labelpad=15, fontsize=12)
    plt.ylabel("True Label", labelpad=15, fontsize=12)
    plt.subplots_adjust(bottom=0.25, top=0.92, left=0.2, right=0.95)
    metrics_text = (f"Accuracy: {accuracy:.4f} | Precision: {precision:.4f}\nRecall: {recall:.4f} | F1: {f1:.4f}")
    plt.figtext(0.5, 0.1, metrics_text, ha="center", fontsize=11, bbox=dict(facecolor='white', alpha=0.8, boxstyle='round,pad=0.5'))
    ax.set_xticks([x + 0.5 for x in range(len(class_names))], minor=True)
    ax.set_yticks([y + 0.5 for y in range(len(class_names))], minor=True)
    ax.grid(which='minor', color='gray', linestyle='-', linewidth=0.5)
    return fig

def plot_roc_curve(
    true_labels,
    pred_probs,
    class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
) -> matplotlib.figure.Figure:
    """
    Plot ROC curves for multi-class classification.
    """
    true_labels = np.array(true_labels)
    pred_probs = np.array(pred_probs)
    n_classes = len(class_names)
    all_possible_labels = np.arange(n_classes)

    fpr, tpr, roc_auc = dict(), dict(), dict()
    for i in range(n_classes):
        binary_true_labels = (true_labels == i).astype(int)
        if len(np.unique(binary_true_labels)) > 1:
            fpr[i], tpr[i], _ = roc_curve(binary_true_labels, pred_probs[:, i])
            roc_auc[i] = roc_auc_score(binary_true_labels, pred_probs[:, i])
        else:
            fpr[i], tpr[i], roc_auc[i] = [0], [0], 0.0

    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes

    macro_auc = roc_auc_score(true_labels, pred_probs, multi_class='ovr', average='macro', labels=all_possible_labels)
    
    fig = plt.figure(figsize=(12, 8))
    colors = plt.cm.rainbow(np.linspace(0, 1, n_classes))
    for i, color in zip(range(n_classes), colors):
        plt.plot(fpr[i], tpr[i], color=color, lw=1.5, label=f'{class_names[i]} (AUC = {roc_auc[i]:.2f})')
    plt.plot(all_fpr, mean_tpr, color='navy', linestyle=':', linewidth=3, label=f'Macro-average (AUC = {macro_auc:.2f})')
    plt.plot([0, 1], [0, 1], 'k--', lw=1.5)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.title('Multi-class ROC Curves', fontsize=14)
    plt.legend(loc="center left", bbox_to_anchor=(1.0, 0.5))
    plt.grid(alpha=0.3)
    plt.tight_layout(rect=[0, 0, 0.85, 1])
    return fig

# --- FIX: Call the new robust evaluation function ---
def visualize_model_performance(
    model,
    data_loader,
    device,
    class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
) -> tuple[matplotlib.figure.Figure, matplotlib.figure.Figure]:
    """
    Comprehensive model evaluation and visualization.
    """
    num_total_classes = len(class_names)
    true_labels, pred_probs, pred_labels = evaluate_model(
        model, data_loader, device, num_total_classes=num_total_classes
    )

    cm_fig = plot_confusion_matrix(true_labels, pred_labels, class_names)
    roc_fig = plot_roc_curve(true_labels, pred_probs, class_names)

    return cm_fig, roc_fig
# --- END FIX ---