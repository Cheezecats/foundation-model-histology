import torch.nn as nn

class LogisticMLP(nn.Module):
    def __init__(self, input_dim=3):
        super(LogisticMLP, self).__init__()
        self.input = nn.Linear(input_dim, 64)
        self.reduce_dim1 = nn.Linear(64, 32)
        self.reduce_dim2 = nn.Linear(32, 9)  # Changed from 10 to 9 for 9 classes
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.2)


    def forward(self, x):
        x = self.relu(self.input(x))
        x = self.dropout(x)
        x = self.relu(self.reduce_dim1(x))
        x = self.dropout(x)
        x = self.reduce_dim2(x)
        return x
