# main.py
import torch
import torch.nn as nn
import torch.optim as optim
import os

from model import LogisticMLP
from dataloader import get_data_loaders
from training_manager import TrainingManager, EarlyStopping
from vis_utils import visualize_model_performance

device = "cuda" if torch.cuda.is_available() else "cpu"

def main():
    # Initialize data loaders
    train_loader, val_loader = get_data_loaders(
        train_hdf5_path = "E:/crc_Hibou_L_features.h5",
        val_hdf5_path = "E:/crc_val_Hibou_L_features.h5",
        batch_size=1024
    )

    # Get input dimension from the first batch of data
    sample_features, _ = next(iter(train_loader))
    input_dim = sample_features.shape[1]
    
    # Hyperparameters
    learning_rate = 0.001
    num_epochs = 10

    # Initialize model
    model = LogisticMLP(input_dim=input_dim).to(device)
    model = model.float()  # Ensure model uses float32
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    early_stopping = EarlyStopping(patience=2, min_delta=0)

    # Initialize training manager
    trainer = TrainingManager(
        model,
        optimizer,
        criterion,
        early_stopping,
        logdir="runs/hiboul_mlp",
        monitor="val_loss",
        device=device,
    )
    
    print("TRAIN STARTING...")
    trainer.train(num_epochs, train_loader, val_loader)
    
    # Visualize performance
    cm_fig, roc_fig = visualize_model_performance(
        model,
        val_loader,
        device,
        class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
    )
    
    # Save results
    from pathlib import Path
    fig_dir = Path(__file__).parent / "figs_mlp"
    os.makedirs(fig_dir, exist_ok=True)
    cm_fig.savefig(os.path.join(fig_dir, "confusion_matrix.png"), bbox_inches='tight')
    roc_fig.savefig(os.path.join(fig_dir, "roc_curve.png"), bbox_inches='tight')
    print(f"Results saved to {fig_dir}")

if __name__ == "__main__":
    main()