import torch
import torch.nn as nn
from torch.optim import Optimizer
from torch.utils.tensorboard.writer import SummaryWriter
from torch.utils.data.dataloader import DataLoader
from tqdm import tqdm
from typing import Literal


class EarlyStopping:
    """Early stopping to prevent overfitting. This class is correct."""
    def __init__(self, patience: int, min_delta: float):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.best_model = None

    def __call__(self, current_value: float, model: nn.Module):
        if self.best_loss is None:
            self.best_loss = current_value
            self.best_model = self._get_model_copy(model)
            return False

        if current_value < self.best_loss - self.min_delta:
            self.best_loss = current_value
            self.counter = 0
            self.best_model = self._get_model_copy(model)
        else:
            self.counter += 1

        if self.counter >= self.patience:
            return True
        return False

    def _get_model_copy(self, model: nn.Module) -> dict:
        return {
            key: val.cpu().clone().detach()
            for key, val in model.state_dict().items()
        }


class TrainingManager:
    def __init__(
        self,
        model: nn.Module,
        optimizer: Optimizer,
        criterion: nn.Module,
        early_stopping: EarlyStopping,
        logdir: str,
        monitor: Literal["val_loss", "val_acc"],
        device: str,
        num_epochs: int,  # NEW: store num_epochs here for robustness
    ):
        self.model = model
        self.optimizer = optimizer
        self.criterion = criterion
        self.device = device
        self.writer = SummaryWriter(logdir)
        self.model.to(device)
        self.monitor = monitor
        self.early_stopping = early_stopping
        self.num_epochs = num_epochs  # store it

    def train(
        self, train_loader: DataLoader, val_loader: DataLoader
    ):
        for epoch in range(self.num_epochs):
            train_loss, train_acc = self.train_epoch(train_loader, epoch)
            val_loss, val_acc = self.validate(val_loader, epoch)

            # If monitoring accuracy, convert to "lower is better" quantity.
            # Using 100 - acc (since acc is in %) keeps min_delta semantics intuitive.
            monitor_value = (
                val_loss if self.monitor == "val_loss" else (100.0 - val_acc)
            )

            if self.early_stopping(monitor_value, self.model):
                print(f"\nEarly stopping triggered after epoch {epoch + 1}")
                break

    def train_epoch(self, train_loader: DataLoader, epoch: int):
        self.model.train()
        loss_sum, correct, total = 0.0, 0, 0

        pbar = tqdm(train_loader, desc=f"Epoch {epoch + 1}/{self.num_epochs}")
        for batch_idx, (data, targets) in enumerate(pbar):
            data, targets = data.to(self.device), targets.to(self.device)

            self.optimizer.zero_grad()
            outputs = self.model(data)
            loss = self.criterion(outputs, targets)

            loss.backward()
            self.optimizer.step()

            # Sample-weighted accumulation
            bs = targets.size(0)
            loss_sum += loss.item() * bs
            _, predicted = torch.max(outputs, 1)
            total += bs
            correct += (predicted == targets).sum().item()

            pbar.set_postfix({
                "loss": loss_sum / max(total, 1),
                "acc": 100.0 * correct / max(total, 1),
            })

        epoch_loss = loss_sum / max(total, 1)
        epoch_acc = 100.0 * correct / max(total, 1)
        self.writer.add_scalar("Loss/train", epoch_loss, epoch)
        self.writer.add_scalar("Accuracy/train", epoch_acc, epoch)
        return epoch_loss, epoch_acc

    def validate(self, val_loader: DataLoader, epoch: int):
        self.model.eval()
        loss_sum, correct, total = 0.0, 0, 0

        with torch.no_grad():
            for data, targets in val_loader:
                data, targets = data.to(self.device), targets.to(self.device)
                outputs = self.model(data)

                loss = self.criterion(outputs, targets)

                # Sample-weighted accumulation
                bs = targets.size(0)
                loss_sum += loss.item() * bs
                _, predicted = torch.max(outputs, 1)
                total += bs
                correct += (predicted == targets).sum().item()

        val_loss = loss_sum / max(total, 1)
        val_acc = 100.0 * correct / max(total, 1)
        self.writer.add_scalar("Loss/validation", val_loss, epoch)
        self.writer.add_scalar("Accuracy/validation", val_acc, epoch)
        print(f"Validation - Loss: {val_loss:.4f}, Accuracy: {val_acc:.2f}%")
        return val_loss, val_acc

    def get_best_model(self) -> dict:
        if self.early_stopping.best_model is None:
            raise Exception("Training not started or no best model saved.")
        return self.early_stopping.best_model