from sklearn.neighbors import KNeighborsClassifier
from sklearn.decomposition import IncrementalPCA
import numpy as np
import torch

class KNNModel:
    def __init__(self, n_neighbors=5, weights='distance', n_components=100, batch_size=5000):
        self.n_neighbors = n_neighbors
        self.weights = weights
        self.batch_size = batch_size
        self.pca = IncrementalPCA(n_components=n_components) if n_components else None
        self.model = KNeighborsClassifier(n_neighbors=n_neighbors, weights=weights, algorithm='kd_tree')
        
    def _convert_to_numpy(self, data):
        """Convert input to numpy array efficiently"""
        if isinstance(data, torch.Tensor):
            return data.numpy().astype('float32')
        return data.astype('float32') if data.dtype != 'float32' else data
        
    def fit(self, X, y):
        X = self._convert_to_numpy(X)
        y = y.numpy() if isinstance(y, torch.Tensor) else y
        
        # Flatten sequence dimension if needed
        if X.ndim > 2:
            X = X.reshape(X.shape[0], -1)
            
        # Incremental PCA fitting for large datasets
        if self.pca:
            for i in range(0, len(X), self.batch_size):
                batch = X[i:i+self.batch_size]
                self.pca.partial_fit(batch)
            X = self.pca.transform(X)
            
        self.model.fit(X, y)
        
    def predict_proba(self, X):
        X = self._convert_to_numpy(X)
        if X.ndim > 2:
            X = X.reshape(X.shape[0], -1)
        if self.pca:
            X = self.pca.transform(X)
        return self.model.predict_proba(X)
        
    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)