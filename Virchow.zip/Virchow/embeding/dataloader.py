from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset
import timm
import torch
from timm.data import resolve_data_config
from timm.data.transforms_factory import create_transform
from timm.layers import SwiGLUPacked
import torch.nn as nn
import os

def create_virchow_model():
    """Initialize Virchow2 model with correct architecture"""
    model = timm.create_model("hf_hub:paige-ai/Virchow", pretrained=True, mlp_layer=SwiGLUPacked, act_layer=torch.nn.SiLU)
    model = model.eval()
    transforms = create_transform(**resolve_data_config(model.pretrained_cfg, model=model))
    return model, transforms

class CRCDataset(Dataset):
    def __init__(self, root_dir):
        self.root_dir = Path(root_dir).absolute()  # Convert to absolute path
        self.classes = ['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
        self.class_to_idx = {cls: i for i, cls in enumerate(self.classes)}
        
        # Get transforms from model config
        _, transforms = create_virchow_model()
        self.transform = transforms

        # Collect all image paths and labels from filenames
        self.image_paths = []
        self.labels = []
        
        # Debugging output
        print(f"\nDataset initialization debug:")
        print(f"Looking in: {self.root_dir}")
        print(f"Directory exists: {self.root_dir.exists()}")
        if self.root_dir.exists():
            print(f"Directory contents: {os.listdir(self.root_dir)[:10]}...")  # Show first 10 files
        
        for img_path in self.root_dir.glob("*.png"):            
            # Try different filename parsing methods
            filename = img_path.stem
            class_name = None
            
            # Method 1: First 3 characters as class code
            if len(filename) >= 3:
                class_name = filename[:3]
            
            # Method 2: Split on first underscore or hyphen
            if class_name not in self.class_to_idx:
                for sep in ['_', '-']:
                    parts = filename.split(sep)
                    if len(parts) > 1 and parts[0] in self.class_to_idx:
                        class_name = parts[0]
                        break
            
            if class_name in self.class_to_idx:
                self.image_paths.append(img_path)
                self.labels.append(self.class_to_idx[class_name])
                # print(f"Found: {img_path.name} -> Class: {class_name}")
            else:
                print(f"Skipped (unknown class): {img_path.name}")

        print(f"\nFound {len(self.image_paths)} valid images")
        if len(self.image_paths) == 0:
            print("Warning: No valid images found! Check:")
            print("1. The directory contains PNG files")
            print("2. Files start with class prefixes like ADI_, TUM-, etc.")
            print(f"Current directory: {os.getcwd()}")
            print(f"Full path: {self.root_dir}")

    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        img = Image.open(self.image_paths[idx])
        if img.mode != 'RGB':
            img = img.convert('RGB')
        return self.transform(img), self.labels[idx]