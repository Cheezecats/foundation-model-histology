# main.py
import os
from dataloader import get_data_loaders
from model import KNNModel
from vis_utils import visualize_model_performance
import torch
import numpy as np
from tqdm import tqdm

def main():
    # Hyperparameters
    n_neighbors = 5
    pca_components = 100  # Set to None to disable PCA
    
    # Initialize KNN with memory-efficient settings
    model = KNNModel(
        n_neighbors=n_neighbors,
        weights='distance',
        n_components=pca_components,
        batch_size=5000
    )
    
    # Get data loaders
    train_loader, val_loader = get_data_loaders(
        train_hdf5_path = "E:/crc_phikon_v1_features.h5",
        val_hdf5_path = "E:/crc_val_phikon_v1_features.h5",
        batch_size=1024
    )

    # Verify data shapes
    sample_batch = next(iter(train_loader))
    print(f"Train batch - data shape: {sample_batch[0].shape}, targets shape: {sample_batch[1].shape}")

    # --- FIX: Accumulate all training data before fitting ---
    print("Loading all training data into memory...")
    X_train_all, y_train_all = [], []
    for data, targets in tqdm(train_loader, desc="Loading Training Data"):
        X_train_all.append(data)
        y_train_all.append(targets)
        
    # Concatenate all batches into single numpy arrays
    X_train_all = torch.cat(X_train_all).numpy()
    y_train_all = torch.cat(y_train_all).numpy()

    print(f"\nTraining KNN model on {len(X_train_all)} samples...")
    # Fit the model ONCE with all the data
    model.fit(X_train_all, y_train_all)
    # --- END FIX ---

    # Evaluate
    print("Evaluating...")
    class_names = ['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
    cm_fig, roc_fig = visualize_model_performance(
        model, 
        val_loader, 
        device='cpu',
        class_names=class_names
    )
    
    # Save results
    from pathlib import Path
    fig_dir = Path(__file__).parent / "figs_knn"
    os.makedirs(fig_dir, exist_ok=True)
    cm_fig.savefig(os.path.join(fig_dir, "confusion_matrix.png"), bbox_inches='tight')
    roc_fig.savefig(os.path.join(fig_dir, "roc_curve.png"), bbox_inches='tight')
    print(f"Results saved to {fig_dir}")

if __name__ == "__main__":
    main()