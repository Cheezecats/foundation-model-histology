# model.py (Corrected)

from sklearn.neighbors import KNeighborsClassifier
from sklearn.decomposition import IncrementalPCA
import numpy as np
import torch

class KNNModel:
    def __init__(self, n_neighbors=5, weights='distance', n_components=100, batch_size=5000):
        self.n_neighbors = n_neighbors
        self.weights = weights
        self.batch_size = batch_size
        self.pca = IncrementalPCA(n_components=n_components, whiten=True) if n_components else None
        self.model = KNeighborsClassifier(
            n_neighbors=n_neighbors, 
            weights=weights, 
            algorithm='auto',
            metric='cosine'
        )
        self.feature_mean = None
        self.feature_std = None

    def _convert_to_numpy(self, data):
        """Convert input to numpy array efficiently"""
        if isinstance(data, torch.Tensor):
            return data.numpy()
        elif isinstance(data, np.ndarray):
            return data
        else:
            return np.array(data)
        
    def _normalize_features(self, X):
        """Normalize features to zero mean and unit variance"""
        # --- FIX 1: Convert to float32 to prevent overflow with float16 data ---
        X_32 = X.astype(np.float32)

        if self.feature_mean is None or self.feature_std is None:
            print("Calculating and storing normalization parameters (mean/std).")
            self.feature_mean = X_32.mean(axis=0)
            self.feature_std = X_32.std(axis=0) + 1e-8  # Avoid division by zero
            
        return (X_32 - self.feature_mean) / self.feature_std
        
    def fit(self, X, y):
        X = self._convert_to_numpy(X)
        y = y.numpy() if isinstance(y, torch.Tensor) else y
        
        if X.ndim > 2:
            X = X.reshape(X.shape[0], -1)
            
        # Normalize features first
        X_norm = self._normalize_features(X)
            
        if self.pca:
            print(f"Original shape: {X_norm.shape}")
            # Fit PCA on the normalized data
            for i in range(0, len(X_norm), self.batch_size):
                batch = X_norm[i:i+self.batch_size]
                self.pca.partial_fit(batch)
            
            # Transform the normalized data
            X_transformed = self.pca.transform(X_norm)
            
            print(f"After PCA shape: {X_transformed.shape}")
            explained_variance = self.pca.explained_variance_ratio_.sum()
            print(f"Explained variance: {explained_variance:.2f}")
        else:
            X_transformed = X_norm
            
        self.model.fit(X_transformed, y)
        
    def predict_proba(self, X):
        X = self._convert_to_numpy(X)
        if X.ndim > 2:
            X = X.reshape(X.shape[0], -1)
        
        # --- FIX 2: Apply the same normalization used during training ---
        X_norm = self._normalize_features(X)
        
        if self.pca:
            X_transformed = self.pca.transform(X_norm)
        else:
            X_transformed = X_norm

        return self.model.predict_proba(X_transformed)
        
    def predict(self, X):
        # This function now correctly uses the fixed predict_proba
        return np.argmax(self.predict_proba(X), axis=1)