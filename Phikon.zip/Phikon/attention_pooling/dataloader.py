# dataloader.py
import torch
from torch.utils.data import Dataset, DataLoader
import h5py
import numpy as np

class CRCDataset(Dataset):
    def __init__(self, hdf5_path, transform=None):
        self.file_path = hdf5_path
        self.transform = transform
        self.file = None  # Will be opened lazily in __getitem__
        with h5py.File(hdf5_path, 'r') as f:
            self._length = len(f['labels'])

    def __len__(self):
        return self._length

    def __getitem__(self, idx):
        if self.file is None:
            self.file = h5py.File(self.file_path, 'r')
        embedding = torch.tensor(self.file['patch_tokens'][idx], dtype=torch.float32)
        label = int(self.file['labels'][idx])
        if self.transform:
            embedding = self.transform(embedding)
        return embedding, label
    
def get_data_loaders(train_hdf5_path, val_hdf5_path, batch_size=32, num_workers=0):
    # Create separate datasets for train and validation
    train_dataset = CRCDataset(train_hdf5_path)
    val_dataset = CRCDataset(val_hdf5_path)
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        persistent_workers=False
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        persistent_workers=False
    )
    
    return train_loader, val_loader