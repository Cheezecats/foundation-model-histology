import torch
import torch.nn as nn

# In model.py
class AttentionModel(nn.Module):
    def __init__(self, input_dim=768, num_classes=9):
        super(AttentionModel, self).__init__()
        
        self.projection = nn.Sequential(
            nn.Linear(input_dim, 512),
            nn.ReLU(),
            nn.Dropout(0.3))
        
        # Attention mechanism
        self.attention = nn.Sequential(
            nn.Linear(512, 256),
            nn.Tanh(),
            nn.Linear(256, 1),
            nn.Softmax(dim=1))  # Across sequence dimension
        
        self.classifier = nn.Sequential(
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes))
        
    def forward(self, x):
        # x shape: [batch_size, seq_len, input_dim]
        batch_size, seq_len, _ = x.shape
        
        # Project all tokens
        projected = self.projection(x)  # [batch_size, seq_len, 512]
        
        # Compute attention weights
        attention_weights = self.attention(projected)  # [batch_size, seq_len, 1]
        
        # Apply attention weights
        weighted_features = attention_weights * projected  # [batch_size, seq_len, 512]
        
        # Sum over sequence dimension
        aggregated = weighted_features.sum(dim=1)  # [batch_size, 512]
        
        # Classify
        logits = self.classifier(aggregated)  # [batch_size, num_classes]
        return logits