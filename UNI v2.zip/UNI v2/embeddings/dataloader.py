from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset
import timm
from timm.data import resolve_data_config
from timm.data.transforms_factory import create_transform
import torch  # <-- Import torch
import os

def create_UNI_model():
    """Initialize UNI model with correct architecture"""
    
    # --- MODIFICATION START ---
    # These are the specific architectural parameters required to build the custom UNI2-h model.
    # They must be passed to timm.create_model to ensure the architecture matches the pretrained weights.
    timm_kwargs = {
        'img_size': 224, 
        'patch_size': 14, 
        'depth': 24,
        'num_heads': 24,
        'init_values': 1e-5, 
        'embed_dim': 1536,
        'mlp_ratio': 2.66667 * 2,
        'num_classes': 0, 
        'no_embed_class': True,
        'mlp_layer': timm.layers.SwiGLUPacked, 
        'act_layer': torch.nn.SiLU, 
        'reg_tokens': 8, 
        'dynamic_img_size': True
    }

    # Pass the kwargs to the create_model function
    model = timm.create_model("hf-hub:MahmoodLab/UNI2-h", pretrained=True, **timm_kwargs)
    # --- MODIFICATION END ---

    transform = create_transform(**resolve_data_config(model.pretrained_cfg, model=model))
    model.eval()
    return model, transform

class CRCDataset(Dataset):
    def __init__(self, root_dir):
        self.root_dir = Path(root_dir).absolute()
        self.classes = ['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
        self.class_to_idx = {cls: i for i, cls in enumerate(self.classes)}
        
        # Get transforms from model config
        # This call to create_UNI_model is only for getting the transform.
        # It's a bit inefficient since it loads the model twice, but it works for this script's purpose.
        # A more optimized approach would be to create the model once in main.py and pass the transform to the dataset.
        # However, for now, we will keep your original structure.
        _, transforms = create_UNI_model()
        self.transform = transforms

        self.image_paths = []
        self.labels = []
        
        print(f"\nDataset initialization debug:")
        print(f"Looking in: {self.root_dir}")
        print(f"Directory exists: {self.root_dir.exists()}")
        if self.root_dir.exists():
            print(f"Directory contents: {os.listdir(self.root_dir)[:10]}...")
        
        for img_path in self.root_dir.glob("*.png"):            
            filename = img_path.stem
            class_name = None
            
            if len(filename) >= 3:
                class_name = filename[:3]
            
            if class_name not in self.class_to_idx:
                for sep in ['_', '-']:
                    parts = filename.split(sep)
                    if len(parts) > 1 and parts[0] in self.class_to_idx:
                        class_name = parts[0]
                        break
            
            if class_name in self.class_to_idx:
                self.image_paths.append(img_path)
                self.labels.append(self.class_to_idx[class_name])
            else:
                print(f"Skipped (unknown class): {img_path.name}")

        print(f"\nFound {len(self.image_paths)} valid images")
        if len(self.image_paths) == 0:
            print("Warning: No valid images found!")

    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        img = Image.open(self.image_paths[idx])
        if img.mode != 'RGB':
            img = img.convert('RGB')
        return self.transform(img), self.labels[idx]