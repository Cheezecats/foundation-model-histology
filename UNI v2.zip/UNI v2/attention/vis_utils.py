import matplotlib.figure
import matplotlib.pyplot as plt
import matplotlib
import seaborn as sns
from sklearn.metrics import (
    confusion_matrix,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_curve,
    roc_auc_score,
)
import torch
import torch.nn as nn
from torch.utils.data.dataloader import DataLoader
import numpy as np


def evaluate_model(
    model: nn.Module, val_loader: DataLoader, device: str
) -> tuple[list[float], list[float], list[float]]:
    """
    Evaluate the model and return true labels, predicted probabilities and predicted labels.
    """
    model.eval()
    true_labels = []
    pred_probs = []
    pred_labels = []

    with torch.no_grad():
        for data, targets in val_loader:  # Changed from (data, _, targets) to (data, targets)
            data, targets = data.to(device), targets.to(device)
            outputs = model(data)

            # Get probabilities using softmax for multi-class
            pred_prob = torch.softmax(outputs, dim=1)

            # Get predicted class indices
            _, predicted = torch.max(outputs, 1)

            pred_probs.extend(pred_prob.cpu().numpy())
            pred_labels.extend(predicted.cpu().numpy())
            true_labels.extend(targets.cpu().numpy())

    return true_labels, pred_probs, pred_labels

def plot_confusion_matrix(
    true_labels,
    pred_labels,
    class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
) -> matplotlib.figure.Figure:
    """
    Plot confusion matrix with metrics.
    """
    # Calculate metrics
    accuracy = accuracy_score(true_labels, pred_labels)
    precision = precision_score(true_labels, pred_labels, average='macro', zero_division=0)
    recall = recall_score(true_labels, pred_labels, average='macro', zero_division=0)
    f1 = f1_score(true_labels, pred_labels, average='macro', zero_division=0)

    # Create confusion matrix - assuming classes are 0-8, so labels up to 8
    cm = confusion_matrix(true_labels, pred_labels, labels=range(len(class_names)))

    # Create larger figure with adjusted layout
    fig = plt.figure(figsize=(12, 10))
    ax = sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        cbar=False,
        xticklabels=class_names,
        yticklabels=class_names,
        annot_kws={"size": 12},
    )

    # Rotate x-axis labels for better readability
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0)

    # Adjust layout
    plt.title("Confusion Matrix", pad=20)
    plt.xlabel("Predicted Label", labelpad=10)
    plt.ylabel("True Label", labelpad=10)

    # Metrics text box
    plt.figtext(
        0.5,
        0.05,
        f"Accuracy: {accuracy:.4f} | Precision: {precision:.4f} | Recall: {recall:.4f} | F1: {f1:.4f}",
        ha="center",
        fontsize=10,
        bbox=dict(facecolor='white', alpha=0.8)
    )

    plt.tight_layout()
    return fig


def plot_roc_curve(
    true_labels,
    pred_probs,
    class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
) -> matplotlib.figure.Figure:
    """
    Plot ROC curves for multi-class classification showing:
    - Individual ROC curves for each class
    - Macro-average ROC curve
    """
    true_labels = np.array(true_labels)
    pred_probs = np.array(pred_probs)
    n_classes = len(class_names)

    # 1. Compute ROC curve and ROC area for each class
    fpr = dict()
    tpr = dict()
    roc_auc = dict()

    for i in range(n_classes):
        # Create binary labels for the current class vs. all others
        binary_true_labels = (true_labels == i).astype(int)
        fpr[i], tpr[i], _ = roc_curve(binary_true_labels, pred_probs[:, i])
        roc_auc[i] = roc_auc_score(binary_true_labels, pred_probs[:, i])

    # 2. Compute macro-average ROC curve and ROC area
    all_fpr = np.unique(np.concatenate([fpr[i] for i in range(n_classes)]))
    mean_tpr = np.zeros_like(all_fpr)
    for i in range(n_classes):
        mean_tpr += np.interp(all_fpr, fpr[i], tpr[i])
    mean_tpr /= n_classes

    # Compute macro AUC properly
    macro_auc = roc_auc_score(true_labels, pred_probs, multi_class='ovr', average='macro')

    # Plot settings
    fig = plt.figure(figsize=(12, 8)) # Increased figure width for legend
    colors = plt.cm.rainbow(np.linspace(0, 1, n_classes))  # Different color for each class

    # Plot individual ROC curves
    for i, color in zip(range(n_classes), colors):
        plt.plot(fpr[i], tpr[i], color=color, lw=1.5,
                 label=f'{class_names[i]} (AUC = {roc_auc[i]:.2f})')

    # Plot macro-average ROC curve
    plt.plot(all_fpr, mean_tpr,
             color='navy', linestyle=':', linewidth=3,
             label=f'Macro-average (AUC = {macro_auc:.2f})')

    # Reference line
    plt.plot([0, 1], [0, 1], 'k--', lw=1.5)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.title('Multi-class ROC Curves', fontsize=14)
    plt.legend(loc="center left", bbox_to_anchor=(1.0, 0.5)) # Move legend outside
    plt.grid(alpha=0.3)
    plt.tight_layout(rect=[0, 0, 0.85, 1]) # Adjust for legend

    return fig


def visualize_model_performance(
    model,
    data_loader,
    device,
    class_names=['ADI', 'BACK', 'DEB', 'LYM', 'MUC', 'MUS', 'NORM', 'STR', 'TUM']
) -> tuple[matplotlib.figure.Figure, matplotlib.figure.Figure]:
    """
    Comprehensive model evaluation and visualization.
    """
    true_labels, pred_probs, pred_labels = evaluate_model(
        model, data_loader, device
    )

    cm_fig = plot_confusion_matrix(true_labels, pred_labels, class_names)
    roc_fig = plot_roc_curve(true_labels, pred_probs, class_names)

    return cm_fig, roc_fig